from django.contrib import admin
from django.urls import path
from home import views






urlpatterns = [
    path("", views.index, name='home'),
    path("about", views.about, name='about'),
    path("search", views.search, name='search'),
    path("contact", views.contact, name='contact'),
    path("view1", views.view1, name='view1'),
    path("view2", views.view2, name='view2'),
    path("view3", views.view3, name='view3'),
    path("view4", views.view4, name='view4'),
    path("view5", views.view5, name='view5'),
    path("view6", views.view6, name='view6'),
    path("view7", views.view7, name='view7'),
    path("search1", views.search1, name='search1'),
    path("signup", views.signup, name='signup'),
    path("login", views.login, name='login')
]