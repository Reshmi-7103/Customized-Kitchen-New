from django.shortcuts import render, HttpResponse
from datetime import datetime
from home.models import Contact
from django.contrib import messages
import mysql.connector as sql

fn=''
ln=''
s=''
em=''
pwd=''
loc=''



# Create your views here.
def index(request):
    context = {
        "variable1":"My Name is Reshmi Chourasia",
        "variable2":"And this is my First Django Project"
    }
    return render(request, 'index.html', context)
    # return HttpResponse("This is HomePage")

def about(request):
    return render(request, 'about.html')
    # return HttpResponse("This is AboutPage")

def search(request):
    return render(request, 'search.html')
    # return HttpResponse("This is servicesPage")

def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contact = Contact(name=name, email=email, phone=phone, desc=desc, date=datetime.today())
        contact.save()
        messages.success(request, "Your Message Has Been Sent")
    return render(request, 'contact.html')
    # return HttpResponse("This is ContactPage")

def view1(request):
    return render(request, 'view1.html')

def view2(request):
    return render(request, 'view2.html')

def view3(request):
    return render(request, 'view3.html')

def view4(request):
    return render(request, 'view4.html')

def view5(request):
    return render(request, 'view5.html')

def view6(request):
    return render(request, 'view6.html')

def view7(request):
    return render(request, 'view7.html')

def search1(request):
        query = request.GET['query']
        if query=='paneer tikka':
            return render(request, 'Paneer tikka.html')
        elif query=='masala dosa':
            return render(request, 'Masala Dosa.html')
        elif query=='biryani':
            return render(request, 'biryani.html')
        elif query=='chole bhature':
            return render(request, 'chole bhature.html')
        elif query=='pav bhaji':
            return render(request, 'pav bhaji.html')
        elif query=='dal tadka':
            return render(request, 'dal tadka.html')
        elif query=='baigan bharta':
            return render(request, 'bengan bharta.html')
        else:
            return render(request, 'error.html')
        # search1 = search.object.filter(title__icontains=query)
        # params= {'search1': search}
        
    
    

def signup(request):
    global fn,ln,s,em,pwd
    if request.method=="POST":
        m=sql.connect(host="localhost",user="root",password="Reshmi@7103",database='realproject')
        cursor=m.cursor()
        d=request.POST
        for key, value in d.items():
            if key=="first_name":
                fn=value
            if key=="last_name":
                ln=value
            if key=="sex":
                s=value
            if key=="email":
                em=value
            if key=="password":
                pwd=value

        c="insert into users values('{}','{}','{}','{}','{}')".format(fn,ln,s,em,pwd)
        cursor.execute(c)
        m.commit()

    return render(request,'signup.html')

def login(request):
    global em,pwd
    if request.method=="POST":
        m=sql.connect(host="localhost",user="root",password="Reshmi@7103",database='realproject')
        cursor=m.cursor()
        d=request.POST
        for key, value in d.items():
            if key=="email":
                em=value
            if key=="password":
                pwd=value

        c="select *from users where email='{}' and password='{}'".format(em,pwd)
        cursor.execute(c)
        t=tuple(cursor.fetchall())
        if t==():
            return render(request, 'error.html')
        else:
            return render(request, 'index.html')
       

    return render(request,'login.html')

